#!/bin/sh
echo 5000 >/sys/devices/platform/leds-gpio/leds/tp-link:blue:system/delay_off
echo 500 >/sys/devices/platform/leds-gpio/leds/tp-link:blue:system/delay_on
