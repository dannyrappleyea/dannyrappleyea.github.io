#!/bin/sh
echo 500 >/sys/devices/platform/leds-gpio/leds/tp-link:blue:system/delay_off
echo 750 >/sys/devices/platform/leds-gpio/leds/tp-link:blue:system/delay_on
